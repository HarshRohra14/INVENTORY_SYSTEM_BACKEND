const { PrismaClient } = require('@prisma/client');
const nodemailer = require('nodemailer');
const axios = require('axios');

const prisma = new PrismaClient();

/**
 * Notification Service
 * Handles email and WhatsApp notifications for order status changes
 */

/**
 * Send email notification
 * @param {string} to - Recipient email address
 * @param {string} subject - Email subject
 * @param {string} htmlContent - HTML email content
 * @returns {Object} Result of the email sending operation
 */
const sendEmailNotification = async (to, subject, htmlContent) => {
  try {
    if (!process.env.SMTP_HOST) {
      console.warn('SMTP not configured. Skipping real email send.');
      return { success: true, messageId: `email_mock_${Date.now()}`, message: 'Email mocked' };
    }

    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
      tls: {
        // 👇 this is the important part for your "self-signed certificate" error
        rejectUnauthorized: false,
      },
    });

    const info = await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to,
      subject,
      html: htmlContent,
    });

    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error('❌ Email notification failed:', error);
    return {
      success: false,
      message: 'Failed to send email notification',
      error: error.message
    };
  }
};

/**
 * Send WhatsApp notification
 * @param {string} phoneNumber - Recipient phone number (with country code)
 * @param {string} message - WhatsApp message content
 * @returns {Object} Result of the WhatsApp sending operation
 */
const sendWhatsAppNotification = async (phoneNumber, message) => {
  try {
    const apiUrl = process.env.SMARTWHAP_API_URL;
    const apiKey = process.env.SMARTWHAP_API_KEY;
    const sender = process.env.SMARTWHAP_SENDER;

    if (!apiUrl || !apiKey || !sender) {
      console.warn('SmartWhap not configured. Skipping real WhatsApp send.');
      return { success: true, messageId: `whatsapp_mock_${Date.now()}`, message: 'WhatsApp mocked' };
    }

    const to = phoneNumber || process.env.SMARTWHAP_TEST_NUMBER;
    if (!to) {
      console.warn('No WhatsApp recipient. Skipping send.');
      return { success: false, message: 'Missing WhatsApp number' };
    }

    const resp = await axios.post(`${apiUrl}/messages/text`,
      {
        to,
        from: sender,
        message,
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 15000,
      }
    );

    const ok = resp.status >= 200 && resp.status < 300;
    return { success: ok, messageId: resp.data?.id || `smartwhap_${Date.now()}` };
  } catch (error) {
    console.error('❌ WhatsApp notification failed:', error);
    return {
      success: false,
      message: 'Failed to send WhatsApp notification',
      error: error.message
    };
  }
};

/**
 * Send order confirm pending notification
 * @param {Object} order - Order object with all details
 * @returns {Object} Result of the notification operation
 */
const sendOrderConfirmPendingNotification = async (order) => {
  try {
    console.log(`📬 Sending order confirm pending notification for order ${order.orderNumber}`);

    // Prepare email content
    const emailSubject = `Order Approved - Confirmation Required: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #f59e0b;">⏳ Order Approval Pending Confirmation</h2>
        <p>Dear ${order.requester.firstName} ${order.requester.lastName},</p>
        
        <p>Your order <strong>${order.orderNumber}</strong> has been approved by the manager and is waiting for your confirmation.</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
          <li><strong>Approved On:</strong> ${new Date(order.approvedAt).toLocaleString()}</li>
        </ul>

        <h3>Approved Items:</h3>
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background-color: #f3f4f6;">
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Item</th>
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">SKU</th>
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Requested</th>
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Approved</th>
            </tr>
          </thead>
          <tbody>
            ${order.orderItems.map(item => `
              <tr>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.item.name}</td>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.item.sku}</td>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.qtyRequested} ${item.item.unit}</td>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.qtyApproved || item.qtyRequested} ${item.item.unit}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <p><strong>Action Required:</strong> Please review the approved quantities and either confirm the order or raise any issues.</p>
        
        <div style="background-color: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #92400e; margin-top: 0;">Next Steps:</h3>
          <ul style="color: #92400e;">
            <li><strong>Confirm Order:</strong> Accept the approved quantities and finalize the order</li>
            <li><strong>Raise Issue:</strong> Send the order back to the manager for re-evaluation</li>
          </ul>
        </div>
        
        <p>Thank you for using our inventory management system!</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message
    const whatsAppMessage = `⏳ *Order Approval Pending Confirmation: ${order.orderNumber}*

Dear ${order.requester.firstName},

Your order has been approved by the manager and is waiting for your confirmation!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

📋 *Approved Items:*
${order.orderItems.map(item =>
      `• ${item.item.name} (${item.item.sku}): ${item.qtyApproved || item.qtyRequested} ${item.item.unit}`
    ).join('\n')}

⚠️ *Action Required:*
Please review the approved quantities and either:
• ✅ Confirm Order - Accept and finalize
• ❌ Raise Issue - Send back for re-evaluation

Thank you! 🚀`;

    // Send notifications
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.requester.email, emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    // Update notification records
    await prisma.notification.updateMany({
      where: {
        orderId: order.id,
        type: 'ORDER_CONFIRM_PENDING'
      },
      data: {
        isEmail: emailResult.success,
        isWhatsApp: whatsAppResult.success
      }
    });

    return {
      success: true,
      message: 'Order approval notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order approval notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order approval notifications',
      error: error.message
    };
  }
};

/**
 * Send order dispatch notification
 * @param {Object} order - Order object with tracking details
 * @returns {Object} Result of the notification operation
 */
const sendOrderDispatchNotification = async (order) => {
  try {
    console.log(`📬 Sending order dispatch notification for order ${order.orderNumber}`);

    // Prepare email content
    const emailSubject = `Order Dispatched: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #2563eb;">🚚 Order Dispatched</h2>
        <p>Dear ${order.requester.firstName} ${order.requester.lastName},</p>
        
        <p>Your order <strong>${order.orderNumber}</strong> has been dispatched and is on its way!</p>
        
        <h3>Tracking Information:</h3>
        <div style="background-color: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Tracking ID:</strong> ${order.tracking?.trackingId || 'N/A'}</p>
          ${order.tracking?.courierLink ? `<p><strong>Track Online:</strong> <a href="${order.tracking.courierLink}" style="color: #2563eb;">${order.tracking.courierLink}</a></p>` : ''}
        </div>

        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
          <li><strong>Dispatched On:</strong> ${new Date(order.dispatchedAt).toLocaleString()}</li>
        </ul>

        <h3>Dispatched Items:</h3>
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background-color: #f3f4f6;">
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Item</th>
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">SKU</th>
              <th style="border: 1px solid #d1d5db; padding: 8px; text-align: left;">Quantity</th>
            </tr>
          </thead>
          <tbody>
            ${order.orderItems.map(item => `
              <tr>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.item.name}</td>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.item.sku}</td>
                <td style="border: 1px solid #d1d5db; padding: 8px;">${item.qtyApproved || item.qtyRequested} ${item.item.unit}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <p>You can track your order using the tracking ID provided above.</p>
        
        <p>Thank you for using our inventory management system!</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message
    const whatsAppMessage = `🚚 *Order Dispatched: ${order.orderNumber}*

Dear ${order.requester.firstName},

Your order has been dispatched and is on its way!

📦 *Tracking Information:*
• Tracking ID: ${order.tracking?.trackingId || 'N/A'}
${order.tracking?.courierLink ? `• Track Online: ${order.tracking.courierLink}` : ''}

📋 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

📦 *Dispatched Items:*
${order.orderItems.map(item =>
      `• ${item.item.name} (${item.item.sku}): ${item.qtyApproved || item.qtyRequested} ${item.item.unit}`
    ).join('\n')}

You can track your order using the tracking ID above.

Thank you! 🚀`;

    // Send notifications
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.requester.email, emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    // Update notification records
    await prisma.notification.updateMany({
      where: {
        orderId: order.id,
        type: 'ORDER_DISPATCHED'
      },
      data: {
        isEmail: emailResult.success,
        isWhatsApp: whatsAppResult.success
      }
    });

    return {
      success: true,
      message: 'Order dispatch notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order dispatch notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order dispatch notifications',
      error: error.message
    };
  }
};

/**
 * Send system notification
 * @param {string} type - Notification type
 * @param {string} title - Notification title
 * @param {string} message - Notification message
 * @param {string} userId - Optional user ID
 * @param {string} orderId - Optional order ID
 * @returns {Object} Result of the notification operation
 */
const sendSystemNotification = async (type, title, message, userId = null, orderId = null) => {
  try {
    console.log(`📬 Sending system notification: ${title}`);

    // Create notification record
    const notification = await prisma.notification.create({
      data: {
        type,
        title,
        message,
        userId,
        orderId,
        isRead: false,
        isEmail: false,
        isWhatsApp: false
      }
    });

    return {
      success: true,
      message: 'System notification created',
      notification
    };

  } catch (error) {
    console.error('❌ System notification failed:', error);
    return {
      success: false,
      message: 'Failed to create system notification',
      error: error.message
    };
  }
};

/**
 * Notify multiple users: create DB notifications, emit realtime events, and send emails.
 * @param {Array<string>} userIds
 * @param {string} orderId
 * @param {string} type
 * @param {string} title
 * @param {string} message
 * @returns {Object}
 */
const notifyUsers = async (userIds = [], orderId = null, type = 'SYSTEM', title = '', message = '') => {
  try {
    if (!Array.isArray(userIds) || userIds.length === 0) return { success: true, message: 'No users to notify' };

    // Deduplicate and remove falsy ids
    const ids = Array.from(new Set(userIds.filter(Boolean)));

    // Fetch user emails for optional email sending and realtime payload
    const users = await prisma.user.findMany({ where: { id: { in: ids } }, select: { id: true, email: true, firstName: true, lastName: true, phoneNumber: true } });

    // Create notifications in DB (one-by-one to populate relations reliably)
    const created = [];
    for (const u of users) {
      const n = await prisma.notification.create({
        data: {
          type,
          title: title || (type || 'SYSTEM'),
          message,
          userId: u.id,
          orderId: orderId || null,
          isRead: false
        }
      });
      created.push(n);

      // Prepare realtime emit (placeholder for Pusher / Socket.io)
      const realtimePayload = {
        notification: {
          id: n.id,
          type: n.type,
          title: n.title,
          message: n.message,
          orderId: n.orderId,
          createdAt: n.createdAt
        }
      };

      try {
        // If Pusher config present, trigger an event. If not, this is a no-op.
        if (process.env.PUSHER_APP_ID && process.env.PUSHER_KEY && process.env.PUSHER_SECRET) {
          try {
            const Pusher = require('pusher');
            const p = new Pusher({
              appId: process.env.PUSHER_APP_ID,
              key: process.env.PUSHER_KEY,
              secret: process.env.PUSHER_SECRET,
              cluster: process.env.PUSHER_CLUSTER || undefined,
              useTLS: process.env.PUSHER_USE_TLS === 'true'
            });
            // channel: `private-user-{id}` event: `notification`
            p.trigger(`private-user-${u.id}`, 'notification', realtimePayload).catch(() => { });
          } catch (err) {
            // don't fail the whole operation if pusher not installed or triggers fail
            console.warn('Pusher trigger skipped or failed:', err.message);
          }
        }
      } catch (err) {
        console.warn('Realtime emit skipped:', err.message);
      }

      // Send email (non-blocking)
      if (u.email) {
        (async () => {
          try {
            const subject = title || `Notification: ${type}`;
            //const html = `<p>Hi ${u.firstName || ''},</p><p>${message}</p><hr/><p>This is an automated message.</p>`;
            const html = `
<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
  
  <!-- Header -->
  <div style="padding: 16px 24px; background-color: #2563eb; color: #ffffff;">
    <h2 style="margin: 0; font-size: 20px;">${title || 'Notification'}</h2>
  </div>

  <!-- Body -->
  <div style="padding: 24px;">
    <p style="font-size: 14px; color: #111827;">
      Hi <strong>${u.firstName || 'there'}</strong>,
    </p>

    <div style="margin: 16px 0; padding: 16px; background-color: #f3f4f6; border-left: 4px solid #2563eb;">
      <p style="margin: 0; font-size: 14px; color: #374151;">
        ${message}
      </p>
    </div>

    ${orderId ? `
    <p style="font-size: 13px; color: #6b7280;">
      <strong>Related Order ID:</strong> ${orderId}
    </p>
    ` : ''}

    <p style="font-size: 13px; color: #374151;">
      Please log in to the system for more details.
    </p>
  </div>

  <!-- Footer -->
  <div style="padding: 16px 24px; border-top: 1px solid #e5e7eb; background-color: #f9fafb;">
    <p style="margin: 0; font-size: 12px; color: #6b7280;">
      This is an automated notification. Please do not reply to this email.
    </p>
  </div>

</div>
`;

            await sendEmailNotification(u.email, subject, html);
            // mark notification as emailed
            await prisma.notification.update({ where: { id: n.id }, data: { isEmail: true } });
          } catch (err) {
            console.error('Failed to send email for notification', n.id, err.message || err);
          }
        })();
      }
    }

    return { success: true, message: 'Notifications created', data: created };
  } catch (error) {
    console.error('❌ notifyUsers failed:', error);
    return { success: false, message: error.message };
  }
};

/**
 * Send order confirmed notification (to manager)
 * @param {Object} order - Order object with all details
 * @returns {Object} Result of the notification operation
 */
const sendOrderConfirmedNotification = async (order) => {
  try {
    console.log(`📬 Sending order confirmed notification for order ${order.orderNumber}`);

    // Prepare email content for manager
    const emailSubject = `Order Confirmed: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">✅ Order Confirmed</h2>
        <p>Dear Manager,</p>
        
        <p>Order <strong>${order.orderNumber}</strong> has been confirmed by the branch user and is ready for dispatch.</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Requester:</strong> ${order.requester.firstName} ${order.requester.lastName}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>You can now proceed with dispatching this order.</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for manager
    const whatsAppMessage = `✅ *Order Confirmed: ${order.orderNumber}*

Dear Manager,

Order ${order.orderNumber} has been confirmed by ${order.requester.firstName} ${order.requester.lastName} and is ready for dispatch!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Requester: ${order.requester.firstName} ${order.requester.lastName}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

You can now proceed with dispatching this order.

Thank you! 🚀`;

    // Send notifications to manager (if manager email is available)
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification('manager@company.com', emailSubject, emailHtmlContent), // TODO: Get actual manager email
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Order confirmed notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order confirmed notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order confirmed notifications',
      error: error.message
    };
  }
};

/**
 * Send order issue raised notification (to manager)
 * @param {Object} order - Order object with all details
 * @param {string} issueReason - Reason for the issue
 * @returns {Object} Result of the notification operation
 */
const sendOrderIssueRaisedNotification = async (order, issueReason) => {
  try {
    console.log(`📬 Sending order issue raised notification for order ${order.orderNumber}`);

    // Prepare email content for manager
    const emailSubject = `Order Issue Raised: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #dc2626;">⚠️ Order Issue Raised</h2>
        <p>Dear Manager,</p>
        
        <p>Order <strong>${order.orderNumber}</strong> has an issue raised by the branch user and needs re-evaluation.</p>
        
        <div style="background-color: #fef2f2; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #dc2626; margin-top: 0;">Issue Details:</h3>
          <p style="color: #dc2626;"><strong>Reason:</strong> ${issueReason}</p>
        </div>

        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Requester:</strong> ${order.requester.firstName} ${order.requester.lastName}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>Please review the order and re-approve with any necessary changes.</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for manager
    const whatsAppMessage = `⚠️ *Order Issue Raised: ${order.orderNumber}*

Dear Manager,

Order ${order.orderNumber} has an issue raised by ${order.requester.firstName} ${order.requester.lastName} and needs re-evaluation!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Requester: ${order.requester.firstName} ${order.requester.lastName}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

⚠️ *Issue Reason:*
${issueReason}

Please review the order and re-approve with any necessary changes.

Thank you! 🚀`;

    // Send notifications to manager
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification('manager@company.com', emailSubject, emailHtmlContent), // TODO: Get actual manager email
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Order issue raised notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order issue raised notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order issue raised notifications',
      error: error.message
    };
  }
};

/**
 * Send manager reply notification (to branch user)
 * @param {Object} order - Order object with all details
 * @param {string} reply - Manager's reply
 * @returns {Object} Result of the notification operation
 */
const sendManagerReplyNotification = async (order, reply) => {
  try {
    console.log(`📬 Sending manager reply notification for order ${order.orderNumber}`);

    // Prepare email content for branch user
    const emailSubject = `Manager Reply: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #3b82f6;">💬 Manager Reply Received</h2>
        <p>Dear ${order.requester.firstName} ${order.requester.lastName},</p>
        
        <p>Your manager has replied to the issue you raised for order <strong>${order.orderNumber}</strong>.</p>
        
        <div style="background-color: #eff6ff; padding: 15px; border-radius: 8px; margin: 20px 0;">
          <h3 style="color: #1e40af; margin-top: 0;">Manager's Reply:</h3>
          <p style="color: #1e40af;">${reply}</p>
        </div>

        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>Please review the manager's reply and take appropriate action.</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for branch user
    const whatsAppMessage = `💬 *Manager Reply: ${order.orderNumber}*

Dear ${order.requester.firstName},

Your manager has replied to the issue you raised for order ${order.orderNumber}!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Items: ${order.totalItems}
• Value: $${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

💬 *Manager's Reply:*
${reply}

Please review the manager's reply and take appropriate action.

Thank you! 🚀`;

    // Send notifications to branch user
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.requester.email, emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Manager reply notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Manager reply notification failed:', error);
    return {
      success: false,
      message: 'Failed to send manager reply notifications',
      error: error.message
    };
  }
};

/**
 * Send order status update notification (to branch user)
 * @param {Object} order - Order object with all details
 * @param {string} newStatus - New status
 * @returns {Object} Result of the notification operation
 */
const sendOrderStatusUpdateNotification = async (order, newStatus) => {
  try {
    console.log(`📬 Sending order status update notification for order ${order.orderNumber}`);

    const statusMessages = {
      'ARRANGING': {
        subject: 'Order Arranging',
        title: '🧰 Order Arranging',
        message: 'Your branch is arranging and collecting items for this order.',
        emoji: '🧰'
      },
      'ARRANGED': {
        subject: 'Order Arranged',
        title: '✅ Order Arranged',
        message: 'Items for your order have been arranged and are ready at the branch.',
        emoji: '✅'
      },
      'ARRANGING': {
        subject: 'Order Arranging',
        title: '🧰 Order Arranging',
        message: 'Your branch is arranging and collecting items for this order.',
      },
      'SENT_FOR_PACKAGING': {
        subject: 'Order Sent for Packaging',
        title: '📤 Order Sent for Packaging',
        message: 'Your order has been sent to packaging/packager and will be prepared for dispatch.',
        emoji: '📤'
      },
      'UNDER_PACKAGING': {
        subject: 'Order Under Packaging',
        title: '📦 Order Under Packaging',
        message: 'Your order is now being packaged and prepared for dispatch.',
        emoji: '📦'
      },
      'IN_TRANSIT': {
        subject: 'Order Dispatched',
        title: '🚚 Order Dispatched',
        message: 'Your order has been dispatched and is on its way to you.',
        emoji: '🚚'
      }
    };

    const statusInfo = statusMessages[newStatus];
    if (!statusInfo) {
      console.warn(`No configured notification message for status: ${newStatus}. Skipping email/whatsapp notifications.`);
      return { success: true, message: 'No notification configured for this status' };
    }

    // Prepare email content for branch user
    const emailSubject = `${statusInfo.subject}: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">${statusInfo.title}</h2>
        <p>Dear ${order.requester.firstName} ${order.requester.lastName},</p>
        
        <p>${statusInfo.message}</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        ${newStatus === 'IN_TRANSIT' ? '<p>You will be able to track your order and confirm receipt once it arrives.</p>' : ''}
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for branch user
    const whatsAppMessage = `${statusInfo.emoji} *${statusInfo.subject}: ${order.orderNumber}*

Dear ${order.requester.firstName},

${statusInfo.message}

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

${newStatus === 'IN_TRANSIT' ? 'You will be able to track your order and confirm receipt once it arrives.' : ''}

Thank you! 🚀`;

    // Send notifications to branch user
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.requester.email, emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Order status update notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order status update notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order status update notifications',
      error: error.message
    };
  }
};

/**
 * Send order received notification (to manager)
 * @param {Object} order - Order object with all details
 * @returns {Object} Result of the notification operation
 */
const sendOrderReceivedNotification = async (order) => {
  try {
    console.log(`📬 Sending order received notification for order ${order.orderNumber}`);

    // Prepare email content for manager
    const emailSubject = `Order Received Confirmed: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">✅ Order Received Confirmed</h2>
        <p>Dear Manager,</p>
        
        <p>Order <strong>${order.orderNumber}</strong> has been confirmed as received by the branch user.</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Requester:</strong> ${order.requester.firstName} ${order.requester.lastName}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>You can now close this order to complete the workflow.</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for manager
    const whatsAppMessage = `✅ *Order Received Confirmed: ${order.orderNumber}*

Dear Manager,

Order ${order.orderNumber} has been confirmed as received by ${order.requester.firstName} ${order.requester.lastName}!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Requester: ${order.requester.firstName} ${order.requester.lastName}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

You can now close this order to complete the workflow.

Thank you! 🚀`;

    // Send notifications to manager
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification('manager@company.com', emailSubject, emailHtmlContent), // TODO: Get actual manager email
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Order received notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order received notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order received notifications',
      error: error.message
    };
  }
};

/**
 * Send order closed notification (to branch user)
 * @param {Object} order - Order object with all details
 * @returns {Object} Result of the notification operation
 */
const sendOrderClosedNotification = async (order) => {
  try {
    console.log(`📬 Sending order closed notification for order ${order.orderNumber}`);

    // Prepare email content for branch user
    const emailSubject = `Order Closed: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #6b7280;">🔒 Order Closed</h2>
        <p>Dear ${order.requester.firstName} ${order.requester.lastName},</p>
        
        <p>Order <strong>${order.orderNumber}</strong> has been closed and completed successfully.</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>Thank you for using our inventory management system!</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for branch user
    const whatsAppMessage = `🔒 *Order Closed: ${order.orderNumber}*

Dear ${order.requester.firstName},

Order ${order.orderNumber} has been closed and completed successfully!

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

Thank you for using our inventory management system!

Thank you! 🚀`;

    // Send notifications to branch user
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.requester.email, emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.requester?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use requester phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Order closed notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Order closed notification failed:', error);
    return {
      success: false,
      message: 'Failed to send order closed notifications',
      error: error.message
    };
  }
};

/**
 * Send manager reply confirmation notification (to manager)
 * @param {Object} order - Order object with all details
 * @returns {Object} Result of the notification operation
 */
const sendManagerReplyConfirmationNotification = async (order) => {
  try {
    console.log(`📬 Sending manager reply confirmation notification for order ${order.orderNumber}`);

    // Prepare email content for manager
    const emailSubject = `Manager Reply Confirmed: ${order.orderNumber}`;
    const emailHtmlContent = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #059669;">✅ Manager Reply Confirmed</h2>
        <p>Dear Manager,</p>
        
        <p>The branch user has confirmed your reply for the raised issue on order ${order.orderNumber}.</p>
        
        <h3>Order Details:</h3>
        <ul>
          <li><strong>Order Number:</strong> ${order.orderNumber}</li>
          <li><strong>Branch:</strong> ${order.branch.name}</li>
          <li><strong>Requester:</strong> ${order.requester.firstName} ${order.requester.lastName}</li>
          <li><strong>Total Items:</strong> ${order.totalItems}</li>
          <li><strong>Order Value:</strong> ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}</li>
        </ul>

        <p>The order is now ready for status updates (Under Packaging → In Transit).</p>
        
        <hr style="margin: 20px 0; border: none; border-top: 1px solid #e5e7eb;">
        <p style="color: #6b7280; font-size: 12px;">
          This is an automated notification. Please do not reply to this email.
        </p>
      </div>
    `;

    // Prepare WhatsApp message for manager
    const whatsAppMessage = `✅ *Manager Reply Confirmed: ${order.orderNumber}*

Dear Manager,

The branch user has confirmed your reply for the raised issue on order ${order.orderNumber}.

📦 *Order Details:*
• Order: ${order.orderNumber}
• Branch: ${order.branch.name}
• Requester: ${order.requester.firstName} ${order.requester.lastName}
• Items: ${order.totalItems}
• Value: ₹${order.totalValue ? order.totalValue.toFixed(2) : '0.00'}

The order is now ready for status updates (Under Packaging → In Transit).

Thank you! 🚀`;

    // Send notifications to manager
    const [emailResult, whatsAppResult] = await Promise.all([
      sendEmailNotification(order.manager?.email || 'manager@example.com', emailSubject, emailHtmlContent),
      sendWhatsAppNotification(order.manager?.phoneNumber || process.env.SMARTWHAP_TEST_NUMBER, whatsAppMessage) // use manager phoneNumber or fallback
    ]);

    return {
      success: true,
      message: 'Manager reply confirmation notifications sent',
      emailResult,
      whatsAppResult
    };

  } catch (error) {
    console.error('❌ Manager reply confirmation notification failed:', error);
    return {
      success: false,
      message: 'Failed to send manager reply confirmation notifications',
      error: error.message
    };
  }
};

/**
 * Notify users who have pending orders containing a SKU when it comes back in stock
 * @param {string} sku
 */
const notifyItemBackInStock = async (sku) => {
  try {
    if (!sku) return { success: false, message: 'Missing SKU' };

    const orderItems = await prisma.orderItem.findMany({
      where: {
        sku,
        order: {
          status: { not: 'CLOSED_ORDER' }
        }
      },
      include: {
        order: { select: { id: true, requesterId: true, orderNumber: true } }
      }
    });

    if (!orderItems || orderItems.length === 0) return { success: true, message: 'No pending orders for this SKU' };

    const notified = new Set();
    for (const oi of orderItems) {
      const requesterId = oi.order.requesterId;
      if (!requesterId || notified.has(requesterId)) continue;
      notified.add(requesterId);

      await prisma.notification.create({
        data: {
          type: 'NOTIFY_OUT_OF_STOCK_AVAILABLE',
          title: 'Item Back In Stock',
          message: `Item with SKU ${sku} is now available in stock. Please review your pending order ${oi.order.orderNumber}.`,
          userId: requesterId,
          orderId: oi.order.id
        }
      });
    }

    return { success: true, message: 'Notifications created' };
  } catch (error) {
    console.error('❌ notifyItemBackInStock error:', error);
    return { success: false, message: error.message };
  }
};

module.exports = {
  sendEmailNotification,
  sendWhatsAppNotification,
  sendOrderConfirmPendingNotification,
  sendOrderConfirmedNotification,
  sendOrderIssueRaisedNotification,
  sendOrderDispatchNotification,
  sendSystemNotification,
  sendManagerReplyNotification,
  sendOrderStatusUpdateNotification,
  sendOrderReceivedNotification,
  sendOrderClosedNotification,
  sendManagerReplyConfirmationNotification
  , notifyItemBackInStock
  , notifyUsers
};
